/**
 * Project Name:liz-common-utils
 * File Name:DuplicatedRecordFoundException.java
 * Package Name:com.yy.cloud.common.exception
 * Date:Jul 12, 20165:25:50 PM
 * Copyright (c) 2016, chenxj All Rights Reserved.
 *
*/

package com.vanyi.cloud.common.exception;
/**
 * ClassName:DuplicatedRecordFoundException <br/>
 * Function: TODO ADD FUNCTION. <br/>
 * Reason:	 TODO ADD REASON. <br/>
 * Date:     Jul 12, 2016 5:25:50 PM <br/>
 * @author   chenxj
 * @version  
 * @since    JDK 1.8
 * @see 	 
 */
public class DuplicatedRecordFoundException extends RuntimeException {

	/**
	 * serialVersionUID:TODO Description.
	 */
	private static final long serialVersionUID = -7514770748584298157L;

}


package com.vanyi.cloud.common.data.otd.user;

import lombok.Data;

/**
 * Function: TODO ADD FUNCTION. <br/>
 * Reason:	 TODO ADD REASON. <br/>
 * Date:     11/15/18 10:58 AM<br/>
 *
 * @author chenxj
 * @see
 * @since JDK 1.8
 */
@Data
public class UserInfo {
    private String id;
    private String username;
    private String password;
    private String name;
    private String description;
}

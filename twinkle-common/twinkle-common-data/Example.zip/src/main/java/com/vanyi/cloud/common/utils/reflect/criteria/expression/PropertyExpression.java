package com.vanyi.cloud.common.utils.reflect.criteria.expression;

import com.vanyi.cloud.common.utils.filter.PropertyFilter;

/**
 * Function: TODO ADD FUNCTION. <br/>
 * Reason:	 TODO ADD REASON. <br/>
 * Date:     11/14/18 5:12 PM<br/>
 *
 * @author chenxj
 * @see
 * @since JDK 1.8
 */
public interface PropertyExpression {
	PropertyFilter toFilter();
}

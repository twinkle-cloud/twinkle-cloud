package com.vanyi.cloud.common.data.dto;

/**
 * Function: TODO ADD FUNCTION. <br/>
 * Reason:	 TODO ADD REASON. <br/>
 * Date:     11/15/18 11:12 AM<br/>
 *
 * @author chenxj
 * @see
 * @since JDK 1.8
 */
public class authority {
}
